class DIcons {
  DIcons._();

  //label printer
  static const String barCode = 'assets/icons/label_print/bar-code.svg';
  static const String dateTime = 'assets/icons/label_print/date-time.svg';
}
