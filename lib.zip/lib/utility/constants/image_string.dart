class DImages {
  DImages._();

  // -- Label section
  static const String widgetZoomIcon = 'assets/icons/zoom_icon.png';
}
